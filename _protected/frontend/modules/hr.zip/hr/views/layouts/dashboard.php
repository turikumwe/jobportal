<?php $this->beginContent('@frontend/views/layouts/user_dashboard.php'); ?>

<div id="main">
    <?php echo $content ?>
</div>

<?php $this->endContent() ?>