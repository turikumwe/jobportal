<?php
/**
 * @author Eugene Terentev <eugene@terentev.net>
 */
