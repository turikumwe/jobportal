<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\EmplEventApplication */

?>
<div class="empl-event-application-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
