<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\EmplSummary */

?>
<div class="empl-summary-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
