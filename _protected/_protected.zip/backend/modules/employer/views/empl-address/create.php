<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\EmplAddress */

?>
<div class="empl-address-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
