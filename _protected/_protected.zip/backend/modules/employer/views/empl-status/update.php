<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\EmplStatus */
?>
<div class="empl-status-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
