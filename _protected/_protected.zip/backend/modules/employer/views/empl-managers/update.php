<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\EmplManagers */
?>
<div class="empl-managers-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
