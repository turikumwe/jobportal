<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\MdMediator */
?>
<div class="md-mediator-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
