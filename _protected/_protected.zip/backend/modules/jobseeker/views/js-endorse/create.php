<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\JsEndorse */

?>
<div class="js-endorse-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
