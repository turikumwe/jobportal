<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\JsExperience */
?>
<div class="js-experience-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
