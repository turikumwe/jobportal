<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\UserProfile */
?>
<div class="user-profile-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
