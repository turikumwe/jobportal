<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\JsRecommendation */

?>
<div class="js-recommendation-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
