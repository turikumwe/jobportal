<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\CommonPerson */
?>
<div class="common-person-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
